from sklearn.model_selection import train_test_split

import pandas as pd
import os

import json

# Read the wine-quality csv file from the URL
csv_url = (
    "http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
)
try:
    data = pd.read_csv(csv_url, sep=";")
except Exception as e:
    logger.exception(
        "Unable to download training & test CSV, check your internet connection. Error: %s", e
    )

# Split the data into training and test sets. (0.85, 0.15) split.
train, test = train_test_split(data, train_size=0.85)

# The predicted column is "quality" which is a scalar from [3, 9]
""" train_x = train.drop(["quality"], axis=1)
test_x = test.drop(["quality"], axis=1)
train_y = train[["quality"]]
test_y = test[["quality"]] """

ordered_train = train.sort_values(by=['quality'])

ordered_train.to_csv(path_or_buf=os.path.join(os.path.dirname(__file__), 'train' + ".csv"), index=False, header=False)

ordered_train.to_json(path_or_buf=os.path.join(os.path.dirname(__file__), 'train' + ".json"), 
            orient='split', index=False)

test.to_csv(path_or_buf=os.path.join(os.path.dirname(__file__), 'test' + ".csv"), index=False)

# print(ordered_train['quality'].unique())
# print(ordered_train.loc[ ordered_train['quality'] == 3])

file_name = path_or_buf=os.path.join(os.path.dirname(__file__), 'train' + ".json")
file_name2 = path_or_buf=os.path.join(os.path.dirname(__file__), 'train2' + ".json")

with open(file_name) as json_file:
    json_decoded = json.load(json_file)
    
json_decoded['type'] = 'numerical'
json_decoded['data'] = {}#ordered_train['quality'].unique().tolist()
data_json = json_decoded['data']

for value in ordered_train['quality'].unique():
    train_series = ordered_train.loc[ ordered_train['quality'] == value]
    #print(type(train_series))
    #print(train_series.drop(["quality"], axis=1))
    train_series = (train_series.drop(["quality"], axis=1))
    #print(train_series.values)
    
    result = []
    for i in range(train_series.values.shape[0]):
        train_series_str = ','.join(str(e) for e in train_series.values[i])
        
        #print(train_series.values)
        #print(train_series_str)
        #print(type(train_series.values))
        #result.append(','.join(train_series_str.values[i, :]))
        result.append(train_series_str)
    
    """ print(result)
    print(value)
    print(json_decoded) """
    data_json[str(value)] = result

del json_decoded['columns']

with open(file_name, 'w') as json_file:
    json.dump(json_decoded, json_file)
